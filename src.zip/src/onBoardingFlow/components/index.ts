export { default as SkipButton } from './SkipButton';
export { default as PaginationDots } from './PaginationDots';
export { default as NextButton } from './NextButton';
export { default as OnBoardingImage } from './OnBoardingImage';
export { default as HowItWorksSection } from './HowItWorksSection';
